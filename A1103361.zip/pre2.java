import java.util.Scanner;

public class pre2{
    
    public static void main(String[]argv){
        String j;
        System.out.println("請輸入平均售票張數:");
        Scanner sa=new Scanner(System.in);
        j=sa.next();

        String i;
        System.out.println("請輸入總花費成本:");
        Scanner sc=new Scanner(System.in);
        i=sc.next();

        int x;
        int y;
        int n;
        y=i=sc;
        x=j=sa*2000;
        (x/y)*100%=n;
        System.out.println("您的虧損率:"+n);

        switch (n){
        case "=>35%":
               System.out.println("嗯!明年繼續辦");
               break;
        case "=<20":
               System.out.println("虧死了!明年停辦");
               break;
        default:
               System.out.println("獲利(虧損)百分比為:"+n);              
        }
    
    }
}