import java.util.Scanner;

public class pre1{

    public static void main(String[]argv){
       
        for(int i=1;i<=9;i++){
            for(int j=2;j<=8;j++){
                System.out.print(i+"*"+j+"="+i*j+"\t");
            }
            System.out.print("\n");
        }
    }
}
